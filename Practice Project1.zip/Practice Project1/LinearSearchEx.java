package datastructures;

public class LinearSearchEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Iterate through a collection one element at a time.....O(n)
		int[] array= {9,6,7,5,7,3,2,1};
		int index=LinearSearch(array,1);
		if(index!=1)
		{
			System.out.println("Element found at index"+index);
		}
		else
		{
			System.out.println("Element not found");
		}
	}

	private static int LinearSearch(int[] array, int value) {
		// TODO Auto-generated method stub
		for(int i=0;i<array.length;i++)
		{
			if(array[i]==value)
			{
				return i;
			}
		}
		return -1;
	}

}
