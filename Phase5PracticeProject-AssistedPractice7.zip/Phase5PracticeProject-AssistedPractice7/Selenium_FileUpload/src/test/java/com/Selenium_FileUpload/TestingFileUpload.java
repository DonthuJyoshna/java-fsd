package com.Selenium_FileUpload;

import java.io.IOException;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestingFileUpload {
	@Test
	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
//		driver.get("file:///D:/LiveClass_Phase4/HTML_LIVECLASS/Registration.html");
//		//driver.findElement(By.xpath("/html/body/div/input[5]")).sendKeys("file:///D:/Jyoshna/19July2023(Phase5-1)/Phase5PracticeProject-AutomateaWebApplication/Automation1_Code.pdf");
//		WebElement fileInput = driver.findElement(By.id("fileInputId"));
//		String filePath = "D:\\Jyoshna\\10June2023(Phase3-2)\\DISPLAYING USER FEEDBACK Source code.docx"; // Replace with the actual file path
//		fileInput.sendKeys(filePath); // Upload the file by sending the file path to the file input element
		
		driver.get("https://resume.naukri.com/resume-quality-score");
		driver.findElement(By.className("browse")).click();
		Thread.sleep(5000);
		Runtime.getRuntime().exec("D:\\Jyoshna\\19July2023(Phase5-1)\\Phase5PracticeProject-AssistedPractice7\\fileupload.exe");
		
		


		

	}

}
