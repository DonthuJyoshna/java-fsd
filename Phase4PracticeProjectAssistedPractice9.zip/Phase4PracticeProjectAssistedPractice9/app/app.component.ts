import { Component,OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-routing';
  constructor(private formBuilder: FormBuilder,public router:Router) { }
  status = 'You haven\'t signed up yet';
  name = '';
  
  ontyping(event:Event) {
     
    this.name = (<HTMLInputElement>event.target).value;
  }
  signup() {
  
    //  this.status = 'Oops! We are working on it!';
    //  alert(this.status);
     this.router.navigate(["signup"]);
  }
}

