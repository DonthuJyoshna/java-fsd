package com.assisted5.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseOperations {
	 private static final String url = "jdbc:mysql://localhost:3306/";
	    private static final String username = "root";
	    private static final String password = "donthu@192";

	    public static void main(String[] args) {
	        createDatabase("example");
	        selectDatabase("example");
	        dropDatabase("example");
	    }

	    public static void createDatabase(String databaseName) {
	        Connection connection = null;
	        Statement statement = null;

	        try {
	            connection = DriverManager.getConnection(url, username, password);
	            statement = connection.createStatement();

	            String createDatabaseQuery = "CREATE DATABASE " + databaseName;
	            statement.executeUpdate(createDatabaseQuery);

	            System.out.println("Database created successfully: " + databaseName);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            System.out.println("Database creation failed");
	        } finally {
	            // Close resources (statement and connection) in the finally block
	            closeResources(statement, connection);
	        }
	    }

	    public static void selectDatabase(String databaseName) {
	        Connection connection = null;
	        Statement statement = null;

	        try {
	            connection = DriverManager.getConnection(url + databaseName, username, password);
	            statement = connection.createStatement();

	            System.out.println("Selected database: " + databaseName);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            System.out.println("Database selection failed");
	        } finally {
	            // Close resources (statement and connection) in the finally block
	            closeResources(statement, connection);
	        }
	    }

	    public static void dropDatabase(String databaseName) {
	        Connection connection = null;
	        Statement statement = null;

	        try {
	            connection = DriverManager.getConnection(url, username, password);
	            statement = connection.createStatement();

	            String dropDatabaseQuery = "DROP DATABASE " + databaseName;
	            statement.executeUpdate(dropDatabaseQuery);

	            System.out.println("Database dropped successfully: " + databaseName);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            System.out.println("Database drop failed");
	        } finally {
	            // Close resources (statement and connection) in the finally block
	            closeResources(statement, connection);
	        }
	    }

	    private static void closeResources(Statement statement, Connection connection) {
	        if (statement != null) {
	            try {
	                statement.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	        if (connection != null) {
	            try {
	                connection.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}


