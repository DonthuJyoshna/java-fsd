package phase1mainproject;
import java.util.Scanner;
public class Wallet {
	private double balance;

    public Wallet() {
        balance =500;
    }

    public double getBalance() 
    {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }
    public void setBalance(double amount)
    {
    	balance=amount;
    }
}
