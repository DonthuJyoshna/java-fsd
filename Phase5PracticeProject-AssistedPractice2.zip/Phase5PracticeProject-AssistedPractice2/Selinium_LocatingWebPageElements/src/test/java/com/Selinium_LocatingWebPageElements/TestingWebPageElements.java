package com.Selinium_LocatingWebPageElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestingWebPageElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.hyrtutorials.com/p/add-padding-to-containers.html");
		
		//FindElement
		driver.findElement(By.xpath("//*[@id=\"post-body-299858861183690484\"]/div/form/div[1]/input[1]")).sendKeys("Jyoshna");
		
		//FindElements
		List<WebElement> elements=driver.findElements(By.xpath("//div/h1"));
		System.out.println(elements.size());
		for (WebElement element : elements) {
			System.out.println(element.getText());
		}
		
		driver.quit();
	}

}
