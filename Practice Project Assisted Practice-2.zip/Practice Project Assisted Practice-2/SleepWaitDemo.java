package my_multithreading;

public class SleepWaitDemo implements Runnable{
	String name;
	SleepWaitDemo(String name1)
	{
		name=name1;
	}
    public void run()
    {
    	for(int i=1;i<=10;i++)
    	{
    		try {
    			Thread.sleep(1000);
    		}
    		catch(InterruptedException e)
    		{
    			e.printStackTrace();
    		}
    		System.out.println(name+" : "+i);
    	}
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SleepWaitDemo s1=new SleepWaitDemo("Thread1");
		SleepWaitDemo s2=new SleepWaitDemo("Thread2");
		Thread t1=new Thread(s1);
		Thread t2=new Thread(s2);
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=0;i<=10;i++)
		{
			System.out.println("Main: "+i);
		}
		

	}

}
