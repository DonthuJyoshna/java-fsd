package datastructures;
import java.util.Stack;
public class StackEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> stack=new Stack<String>();
		stack.push("Jyoshna");
		stack.push("lahari");
		stack.push("latha");
		stack.push("Prasad");
		stack.pop();
		System.out.println(stack);
		//peek-wont delete the top item just it will return the top item
		System.out.println(stack.peek());
		//There is no zero index in stack...index starts from 1
		System.out.println(stack.search("latha"));
		//If it doesn't found in the stack returns -1
		System.out.println(stack.search("Jarina"));
		
	}

}
