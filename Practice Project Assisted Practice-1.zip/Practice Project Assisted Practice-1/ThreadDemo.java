package my_multithreading;

public class ThreadDemo extends Thread {
    public void run() {
        System.out.println("Hello from MyThread!");
    }

    public static void main(String[] args) {
        ThreadDemo thread = new ThreadDemo();
        Thread t=new Thread(thread);
        t.start(); // This will call the run() method
    }
}
