package my_multithreading;

public class RunnableDemo implements Runnable{
	public void run()
	{
		System.out.println("Hello from MyRunnable!");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunnableDemo rd=new RunnableDemo();
		Thread t=new Thread(rd);
		t.start();

	}

}
