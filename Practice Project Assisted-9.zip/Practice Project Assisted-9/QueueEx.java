package datastructures;
import java.util.*;
public class QueueEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//It is FIFO data structure
		Queue<String> queue=new LinkedList<>();
		queue.offer("Jyoshan");
		queue.offer("J");
		queue.offer("Jyo");
		queue.offer("Jyosh");
		queue.offer("Jyoshna");
		System.out.println(queue);
		queue.poll();
		System.out.println(queue);
		System.out.println(queue.peek());
		System.out.println(queue.isEmpty());
		System.out.println(queue.size());
		System.out.println(queue.contains("Jyoshna"));
		
	}

}
