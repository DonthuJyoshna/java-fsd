package my_practiceproject;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class FileOperations {
	public static void main(String[] args) {
    	        Scanner scanner = new Scanner(System.in);

    	        System.out.print("Enter file name: ");
    	        String fileName = scanner.nextLine();

    	        try {
    	            // Create a new file
    	            File file = new File(fileName);
    	            if (file.createNewFile()) {
    	                System.out.println("File created: " + file.getName());
    	            } else {
    	                System.out.println("File already exists.");
    	            }

    	            // Write some text to the file
    	            FileWriter writer = new FileWriter(file);
    	            System.out.print("Enter text to write to file: ");
    	            String text = scanner.nextLine();
    	            writer.write(text);
    	            writer.close();
    	            System.out.println("Text written to file: " + fileName);

    	            // Read the contents of the file and print them to the console
    	            Scanner fileScanner = new Scanner(file);
    	            System.out.println("File contents: ");
    	            while (fileScanner.hasNextLine()) {
    	                String line = fileScanner.nextLine();
    	                System.out.println(line);
    	            }
    	            fileScanner.close();

    	            // Update the file with some new text
    	            FileWriter appendWriter = new FileWriter(file, true);
    	            System.out.print("Enter text to append to file: ");
    	            String appendText = scanner.nextLine();
    	            appendWriter.write("\n" + appendText);
    	            appendWriter.close();
    	            System.out.println("Text appended to file: " + fileName);

    	            // Read the updated contents of the file and print them to the console
    	            fileScanner = new Scanner(file);
    	            System.out.println("Updated file contents: ");
    	            while (fileScanner.hasNextLine()) {
    	                String line = fileScanner.nextLine();
    	                System.out.println(line);
    	            }
    	            fileScanner.close();

    	            // Delete the file
    	            if (file.delete()) {
    	                System.out.println("File deleted: " + file.getName());
    	            } else {
    	                System.out.println("Failed to delete file.");
    	            }

    	        } catch (IOException e) {
    	            System.out.println("An error occurred: " + e.getMessage());
    	        } finally {
    	            scanner.close();
    	        }
    	    }
    	}

