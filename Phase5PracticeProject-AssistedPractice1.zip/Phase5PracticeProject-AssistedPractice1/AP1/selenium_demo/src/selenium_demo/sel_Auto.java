package selenium_demo;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sel_Auto {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "U:\\seleniumjars\\chromedriver.exe");
        // Create an object to the driver - an object to the browser
        WebDriver wd = new ChromeDriver(); // wd is the controller object for the web browser
        // Maximize the browser window
        wd.manage().window().maximize();
        // Open the web URL
        wd.get("https://www.amazon.in/");
        // Close the browser
        wd.quit();
    }
}
