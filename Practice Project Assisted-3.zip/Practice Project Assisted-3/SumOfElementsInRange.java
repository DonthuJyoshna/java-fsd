package my_assignments;

public class SumOfElementsInRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = {2, 4, 6, 8, 10, 12, 14, 16};
        int n = array.length;
        int L = 2;
        int R = 5;
        
        int sum = findSumOfElementsInRange(array, n, L, R);
        
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
    }
    
    public static int findSumOfElementsInRange(int[] array, int n, int L, int R) {
        if (n <= 0 || L < 0 || R >= n || L > R) {
            throw new IllegalArgumentException("Invalid input");
        }
        
        int sum = 0;
        
        for (int i = L; i <= R; i++) {
            sum += array[i];
        }
        
        return sum;
	}

}
