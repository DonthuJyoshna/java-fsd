package loading_webpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Css_xpath {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "U:\\seleniumjars\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");

                try {
                    // Find the search bar element and enter "Samsung mobiles"
                    WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
                    searchBox.sendKeys("Samsung mobiles");

                    // Submit the search query
                    searchBox.submit();

                    // Wait for the search results to load (you may need to add some waiting here)
                    Thread.sleep(3000);

                    // Handle the search results (for example, print the product names and prices)
                    java.util.List<WebElement> results = driver.findElements(By.xpath("//span[@class='a-size-medium a-color-base a-text-normal']"));
                    java.util.List<WebElement> prices = driver.findElements(By.xpath("//span[@class='a-price-whole']"));

                    for (int i = 0; i < results.size(); i++) {
                        System.out.println("Product Name: " + results.get(i).getText());
                        System.out.println("Price: Rs." + prices.get(i).getText());
                        System.out.println("-------------------------------------");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    // Close the browser after the operation is done
                    driver.quit();
                }     
        
    }
}
