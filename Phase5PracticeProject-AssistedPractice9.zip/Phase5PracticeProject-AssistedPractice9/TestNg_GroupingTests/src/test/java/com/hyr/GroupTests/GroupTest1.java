package com.hyr.GroupTests;

import org.testng.annotations.Test;
@Test(groups = {"all"})
public class GroupTest1 {
	
	
  @Test(groups = {"windows.smoke","functional","sanity"})
  public void test1() {
	  System.out.println("Test1");
  }
  
  
  @Test(groups = {"functional","ios.regression","windows.sanity"})
  public void test2() {
	  System.out.println("Test2");
  }
  
  
  @Test(groups = {"windows.sanity"})
  public void test3() {
	  System.out.println("Test3");
  }
  
  @Test
  public void test9() {
	  System.out.println("Test9");
  }
}
