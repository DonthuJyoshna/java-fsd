package com.hyr.GroupTests;

import org.testng.annotations.Test;

public class GroupTest2 {
  @Test(groups = {"smoke","windows.regression","ios.sanity"})
  public void test4() {
	  System.out.println("Test4");
  }
  @Test(groups = {"sanity"})
  public void test5() {
	  System.out.println("Test5");
  }
  @Test(groups = {"ios.smoke","ios.functional","sanity","windows.regression"})
  public void test6() {
	  System.out.println("Test6");
  }
  @Test
  public void test7() {
	  System.out.println("Test7");
  }
}

