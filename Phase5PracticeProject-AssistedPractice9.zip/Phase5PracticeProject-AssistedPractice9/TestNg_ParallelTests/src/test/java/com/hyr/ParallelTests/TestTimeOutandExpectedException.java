package com.hyr.ParallelTests;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.net.UrlChecker.TimeoutException;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestTimeOutandExpectedException {
	
	//@Test(timeOut = 2000)
	@Test(expectedExceptions = {NoSuchElementException.class})
	public void testmethod1()
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.hyrtutorials.com/");
		driver.findElement(By.id("abcd")).click();
		driver.quit();
	}
	
	

}
