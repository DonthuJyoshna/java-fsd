package com.hyr.ParallelTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBasicParallelDemo {
private WebDriver driver;
	
	@Test(dataProvider = "registerdata")
    public void EnterRegistrationDetails(String username,String phonenumber,String email,String password) {
		WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.amazon.in");
        driver.findElement(By.linkText("Start here.")).click();
        driver.findElement(By.id("ap_customer_name")).sendKeys(username);
        driver.findElement(By.id("ap_phone_number")).sendKeys(phonenumber);
        driver.findElement(By.id("ap_email")).sendKeys(email);
        driver.findElement(By.id("ap_password")).sendKeys(password);
        driver.findElement(By.id("continue")).click();
        driver.quit();
    }
	
	@DataProvider(name="registerdata",parallel=true)
	public Object[][] registerData() {
		Object[][] data = new Object[5][4];
		
		data[0][0] = "Jyoshna";
		data[0][1] = "9381065969";
		data[0][2] = "Jyoshna@gmail.com";
		data[0][3] = "jyoshna";
		
		data[1][0] = "Lahari";
		data[1][1] = "6436579754";
		data[1][2] = "lahari@gmail.com";
		data[1][3] = "lahari";
		
		data[2][0] = "latha";
		data[2][1] = "687436679";
		data[2][2] = "latha@gmail.com";
		data[2][3] = "latha";
		
		data[3][0] = "prasad";
		data[3][1] = "649854760";
		data[3][2] = "prasad@gmail.com";
		data[3][3] = "prasad";
		
		data[4][0] = "vgbj ";
		data[4][1] = " jkgfhg";
		data[4][2] = "bjvbgh@gmail.com";
		data[4][3] = "gjhgv";
		
		return data;
	}

}
