package com.Selenium_Screenshots;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestScreenshots {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com");
		//File
//		File sourceFile=((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
//		File destinationFile=new File("./Screenshots/img1.jpg");
//		FileUtils.copyFile(sourceFile, destinationFile);
//		System.out.println("Screenshot saved Successfully");
//		driver.quit();
		
		//Bytes 
//		byte[] byteArr=((RemoteWebDriver) driver).getScreenshotAs(OutputType.BYTES);
//		File destinationFile=new File("./Screenshots/img2.jpg");
//		FileOutputStream fos=new FileOutputStream(destinationFile);
//		fos.write(byteArr);
//		fos.close();
//		System.out.println("Screenshot saved Successfully..");
//		driver.quit();
		
		//Base64
		String base64code=((RemoteWebDriver) driver).getScreenshotAs(OutputType.BASE64);
		byte[] byteArr=Base64.getDecoder().decode(base64code);
		File destinationFile=new File("./Screenshots/img3.jpg");
		
		FileOutputStream fos=new FileOutputStream(destinationFile);
		fos.write(byteArr);
		fos.close();
		System.out.println("Screenshot saved Successfully..by BASE64");
		driver.quit();

		

	}

}
