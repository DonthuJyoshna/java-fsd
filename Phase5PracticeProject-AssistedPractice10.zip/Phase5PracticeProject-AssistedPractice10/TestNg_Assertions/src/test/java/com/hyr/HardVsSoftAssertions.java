package com.hyr;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HardVsSoftAssertions {
	
	@Test
	public void TestFacebook() throws InterruptedException
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/");
		//driver.findElement(By.name("email")).sendKeys("Jyoshna",Keys.ENTER);		//Hard Assertions----(assertEquals.)---if it fails...next lines wont get execute...Assert
		//Soft Assertions----(assertEquals.)---if it fails...next lines wont get execute...it throws expection at specified location or end of test...SoftAssert
		//Verifying Title,URL,text is empty or not,border of username,error msg
		Thread.sleep(5000);
		
		SoftAssert softAssert=new SoftAssert();
		
		//Title Assertion...Hard Assertion
		String actualTitle=driver.getTitle();
		String expectedTitle="Facebook – log in or sign up";
		softAssert.assertEquals(actualTitle,expectedTitle," Title Mismatched");
		
		//URL Assertion...Hard Assertion
		String actualURL=driver.getCurrentUrl();
		String expectedURL="https://www.facebook.com/";
		softAssert.assertEquals(actualURL,expectedURL," URL Mismatched");
		
		//Text Assertion...Hard Assertion
		
		WebElement emailField = driver.findElement(By.name("email"));

	    // Clear the existing text (if any)
	    emailField.clear();

	    // Send an empty string to the text field
	    emailField.sendKeys("");

	    // Press Enter
	    emailField.sendKeys(Keys.ENTER);

	    // Now, get the value of the input field and store it in actualText
	    String actualText = emailField.getAttribute("value");

	    // Provide the expectedText
	    String expectedText = "";

	    // Compare the actualText with the expectedText using a Hard Assertion
	    assertEquals(actualText, expectedText, "Username Text Mismatched");
	
		
		//Border Assertion...Hard Assertion
		
		String actualBorder=driver.findElement(By.name("email")).getCssValue("value");
		String expectedBorder="1px solid rgb(240,40,73)";
		softAssert.assertEquals(actualBorder,expectedBorder,"Username Border Mismatched");
		
		//ErrorMsg Assertion...Hard Assertion
		String actualErrorMsg=driver.findElement(By.xpath("(//div[@id=\"email_container\"]/div)[last()]")).getText();
		String expectedErrorMsg="The email address or mobile number you entered isn't connected to an account. Find your account and log in.";
		softAssert.assertEquals(actualErrorMsg,expectedErrorMsg,"Username ErrorMsg Mismatched");
		

		
		driver.quit();
		softAssert.assertAll();
	
	
	}

}
