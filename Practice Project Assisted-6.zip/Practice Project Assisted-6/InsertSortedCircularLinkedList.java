package my_assignments;
class Node1 {
    int data;
    Node1 next;

    public Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node1 head;

    public CircularLinkedList() {
        this.head = null;
    }

    public void insert(int data) {
        Node1 newNode = new Node1(data);

        if (head == null) {
            head = newNode;
            head.next = head; // Make it circular
        } else if (data < head.data) {
            Node1 current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            Node1 current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node1 current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}
public class InsertSortedCircularLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircularLinkedList list = new CircularLinkedList();
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(50);

        System.out.println("Original Circular Linked List:");
        list.display();

        int newData = 25;
        list.insert(newData);

        System.out.println("List after inserting " + newData + " into the sorted circular linked list:");
        list.display();
	}

}
