package my_datastructures;

public class MergeSortEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//MergeSort Works on 2 sub-arrays
		int arr[]= {34,12,78,3,90,9};
		mergeSort(arr);
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}

	}

	private static void mergeSort(int[] arr)
	{
		// TODO Auto-generated method stub
		int length=arr.length;
		if(length<=1)
			return;
		int middle=length/2;
		int[] leftArray=new int[middle];
		int[] rightArray=new int[length-middle];
		int i=0;//left array
		int j=0;//right array
		for(;i<length;i++)
		{
			if(i<middle)
			{
				leftArray[i]=arr[i];
			}
			else
			{
				rightArray[j]=arr[i];
				j++;
			}
		}
		mergeSort(leftArray);
		mergeSort(rightArray);
		merge(leftArray,rightArray,arr);
		
	}
    private static void merge(int[] leftArray,int[] rightArray,int[] arr)
    {
    	int leftSize=arr.length/2;
    	int rightSize=arr.length-leftSize;
    	int i=0,l=0,r=0;
    	while(l<leftSize && r<rightSize) 
    	{
    		if(leftArray[l] < rightArray[r]) 
    		{
    			arr[i]=leftArray[l];
    			i++;
    			l++;
    		}
    		else
    		{
    			arr[i]=rightArray[r];
    			i++;
    			r++;
    		}
    	}
    		while(l<leftSize)
    		{
    			arr[i]=leftArray[l];
    			i++;
    			l++;
    		}
    		while(r<rightSize)
    		{
    			arr[i]=rightArray[r];
    			i++;
    			r++;
    		}

    	
    }
}
